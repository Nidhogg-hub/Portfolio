class Car:
    def __init__(self, brand, model, year):
        self.brand = brand
        self.model = model
        self.year = year
    def beskrivelse(self):
        print (f"bil starter: {self.brand} {self.model} fra {self.year}")

min_bil= Car("Audi","A6", 2016)
min_bil.beskrivelse()
