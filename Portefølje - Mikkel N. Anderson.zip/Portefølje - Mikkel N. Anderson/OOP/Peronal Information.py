# Definerer klassen Person
class personInfo:
    def __init__(self, name, address, age, phoneNum):
        self.__name = name
        self.__address = address
        self.__age = age
        self.__phoneNum = phoneNum

    # Accessor-metoder

    def get_name(self):
        return self.__name

    def get_address(self):
        return self.__address

    def get_phone(self):
        return self.__phone

    # Mutator-metoder

    def set_name(self, name):
        self.__name = name

    def set_address(self, address):
        self.__address = address

    def set_age(self, age):
        self.__age = age

    def set_phone(self, phoneNum):
        self.__phoneNum = phoneNum

    #Ekstra: metode til at vise alle oplysninger

    def display_info(self):
        print(f"Navn: {self.__name}")
        print(f"Adresse: {self.__address}")
        print(f"Alder: {self.__age}")
        print(f"Tlf: {self.__phoneNum}")
        print("-" * 30)

# Opretter tre instanser af person-klassen
person1 = personInfo("Test1", "testvej 1, 9999 testby", 50, "12345678")
person2 = personInfo("Test2", "teststræde 14, 8888 testhavn", 30, "23456789")
person3 = personInfo("Test3", "teststræde 40, 8888 testhavn", 25, "34567890")

# Viser oplysninger

person1.display_info()
person2.display_info()
person3.display_info()

