class Employee:
    def __init__(self, name, ID_number, department, job_Title):
        self.__name = name
        self.__ID_number = ID_number
        self.__department = department
        self.__job_Title = job_Title

    #Accessors

    def get_name(self):
        return self.__name

    def get_ID_number(self):
        return self.__ID_number
    
    def get_department(self):
        return self.__department

    def get_job_Title(self):
        return self.__job_Title
    
    #Mutators

    def set_name(self, name):
        self.__name = name

    def set_ID_number(self, ID_number):
        self.__ID_number = ID_number
    
    def set_department(self, department):
        self.__department = department

    def set_job_Title(self, job_Title):
        self._job_Title = job_Title

    def __str__(self):
        return f"{self.__name:<15}{self.__ID_number:<10}{self.__department:<15}{self.__job_Title:<15}"

# Opretter listen med medarbejdere

employees = {
    47899: Employee("Susan Meyers", 47899, "Accounting", "Vice President"),
    39119: Employee("Mark Jones", 39119, "IT", "Programmer"),
    81774: Employee("Joy Rogers",81774, "Manufacturing", "Engineer")
}

# Udskriver Tabellen

print(f"{'Name' :<15}{'ID Number':<10}{'Department':<15}{'Job Title':<15}")
print("-" * 60)
for emp in employees.values():
    print(emp)
