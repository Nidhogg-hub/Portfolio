class Book:
    def __init__ (self, title, author, pages):
        self.title = title
        self.author = author
        self.pages = pages
    def Summary(self):
        print(f" Navnet på bogen er {self.title} og den er skrevet af {self.author}. Den har {self.pages} sider.")


Min_ynglingsbog = Book("testtitle", "testauthor", 1000)
Min_ynglingsbog.Summary()
