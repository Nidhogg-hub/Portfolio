import pickle
import os

FILENAME = "Employee.py"

# Forsøg at indlæse eksisterence data

def load_employees():
    if os.path.exists(FILENAME):
        with open(FILENAME "rb") as file:
            return pickle.load(file)
    else:
        return {}

# Gem data ved afslutning

def save_employees(employee_dict):
    with open(FILENAME, "wb") as file:
        pickle.dump(employee_dict, file)

# Menu

def display_menu():
    print("\nEMPOLYEE MANAGEMENT SYSTEM")
    print("1. Slå medarbejder op")
    print("2. Tilføj ny medarbejder")
    print("3. Andr medarbejder")
    print("4. Slet medarbejder")
    print("5. Vis alle medarbejdere")
    print("6. Afslut")

def main():
    employees = load_employees()

    while True:
        display_menu()
        choice = input("Vælg (1-6): ")

        if choice == "1":
            emp_id = int(input("Indtast ID: "))
            if emp_id in employees:
                print(employees[emp_id])
            else:
                name = input("Navn: ")
                dept = input("Afdeling: ")
                title = input("Jobtitle: ")
                employees[emp_id] = Employee(name, emp_id, dept, title)
                print("Medarbejder tilføjet.")

        elif choice == "3":
            emp_id =int(input("Indtast ID på medarbejder der ændres: "))
            if emp_id in employees:
                name = input("Nyt navn: ")
                dept = input("Ny afdeling: ")
                title = input("Ny jobtitle: ")
                employees[emp_id].set.name(name)
                employees[emp_id].set.department(dept)
                employees[emp_id].set.job_Title(title)
                print("Medarbejder opdateret.")
            else:
                print("Medarbejder ikke fundet.")

        elif choice == "4":
            emp_id = int(input("Indtast ID på medarbejder der skal slettes: "))
            if emp_id in employees:
                del employees[emp_id]
                print("Medarbejder slettet.")
            else:
                print("Medarbejder ikke fundet.")

        elif choice == "5":
            print(f"{'Name':<15}{'ID Number':<10}{'Department':<15}{'Job Title':<15}")
            print("-" * 60)
            for emp in employees.values():
                print(emp)

        elif choice == "6":
            save_employees(employees)
            print("Data gemt. Program afsluttes.")
            break

        else:
            print("Ugyldigt valg.")


if __name__ == "__main__":
    main()
