class RetailItem:
    def __init__(self, itemDescription, units, price):
        self.__itemDescription = itemDescription
        self.__units = units
        self.__price = price

    # Getters (accessors)

    def get_item(self):
        return self.__itemDescription

    def get_units(self):
        return self.__units

    def get_price(self):
        return self.__price

    # Setters (mutators)

    def set_itemDescription(self, itemDescription):
        self.__itemDescription = itemDescription

    def set_units(self, units):
        self.__units = units

    def set_price(self, price):
        self.__price = price

    #For at få det til at stå pænt

    def display_info(self):
        print(f"{self.__itemDescription:<20}{self.__units:<10}{self.__price:>7.2f}kr.")

# Opretter tre RetailItem-objekter

item1 = RetailItem("Jacket", 12, 59.95)
item2 = RetailItem("Designer Jeans", 40, 34.95)
item3 = RetailItem("Shirt", 20, 24.50)

# Udskriver tabel med vare

print(f"{'Description':<20}{'Units':<10}{'Price':>7}")
print("-" * 40)
item1.display_info()
item2.display_info()
item3.display_info()
