class Pet:
    def __init__(self, name, species, age):
        self.name = name
        self.species = species
        self.age = age
    def describe(self):
        print(f"Mit kæledyr hedder {self.name} og det er en {self.species}. Den er {self.age} år gammel")

min_hund = Pet("Skipper", "hund", 15)
min_hund.describe()
