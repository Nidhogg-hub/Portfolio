from datetime import date

#----------------------------------

# Patient-klassen

#----------------------------------

class Patient:
    def __init__(self, firstName, middleName, lastName, address, city, state, zipCode, phone, emergencyName, emergencyContact):
        self.__firstName = firstName
        self.__middleName = middleName
        self.__lastName = lastName
        self.__address = address
        self.__city = city
        self.__state = state
        self.__zipCode = zipCode
        self.__phone = phone
        self.__emergencyName = emergencyName
        self.__emergencyContact = emergencyContact
        
    # Getters (Accessor)

    def get_firstName(self):
        return self.__firstName

    def get_middleName(self):
        return self.__middleName
    
    def get_lastName(self):
        return self.__lastName

    def get_address(self):
        return self.__address
    
    def get_city(self):
        return self.__city

    def get_state(self):
        return self.__state

    def get_zipCode(self):
        return self.__zipCode

    def get_phone(self):
        return self.__phone

    def get_emergencyName(self):
        return self.__emergencyName

    def get_emergencyContact(self):
        return self.__emergencyContact

    #Setters (Mutator)

    def set_firstName(self, firstName):
        self.__firstName = firstName

    def set_middleName(self, middleName):
        self.__middleName = middleName
    
    def set_lastName(self, lastName):
        self.__lastName = lastName

    def set_address(self, address):
        self.__address = address
    
    def set_city(self, city):
        self.__city = city

    def set_state(self, state):
        self.__state = state

    def set_zipCode(self, zipCode):
        self.__zipCode = zipCode

    def set_phone(self, phone):
        self.__phone = phone

    def set_emergencyName(self, emergencyName):
        self.__emergencuName = emergencyName

    def set_emergencyContact(self, emergencyContact):
        self.__emergencyContact = emergencyContact

    def display_info(self):
        print("PATIENT INFORMATION")
        print(f"Name: {self.__firstName}{self.__middleName}{self.__lastName}")
        print(f"Address: {self.__address}, {self.__city}, {self.__state} {self.__zipCode}")
        print(f"Phone: {self.__phone}")
        print(f"Emergency Contact: {self.__emergencyName} ({self.__emergencyContact})")
        print("-" * 50)

#------------------------------------------------

# Procedure-klassen

#------------------------------------------------

class Procedure:
    def __init__(self, nameProcedure, dateProcedure, practitioner, costProcedure):
        self.__nameProcedure = nameProcedure
        self.__dateProcedure = dateProcedure
        self.__practitioner = practitioner
        self.__costProcedure = costProcedure

    # Getters (Accessor)
    def get_nameProcedure(self):
        return self.__nameProcedure

    def get_dateProcedure(self):
        return self.__dateProcedure

    def get_practitioner(self):
        return self.__practitioner

    def get_costProcedure(self):
        return self.__costProcedure


    # Setters (Mutators)
    def set_nameProcedure(self, nameProcedure):
        self.__nameProcedure = nameProcedure

    def set_dateProcedure(self, dateProcedure):
        self.__dateProcedure = dateProcedure

    def set_practitioner(self, practitioner):
        self.__practitioner = practitioner

    def set_costProcedure(self, costProcedure):
        self.__costProcedure = costProcedure

    def display_info(self):
        print(f"Procedure: {self.__nameProcedure}")
        print(f"Date: {self.__dateProcedure}")
        print(f"Practitioner: {self.__practitioner}")
        print(f"Charge: ${self.__costProcedure: .2f}")
        print("-" * 50)

# Opret patient

patient = Patient("John", "Smith", "Doe",
                  "123 Main St", "Springfield", "IL", "62704",
                  "555-1234", "Jane Doe", "555-5678"
)

# Opretter liste over Procedures
today = date.today().strftime("%Y-%m-%d")
procedures = [
    Procedure("Physical Exam", today, "Dr. Irvine", 250.00),
    Procedure("X-ray", today, "Dr. Jamison", 500.00),
    Procedure("Blood test", today, "Dr. Smith", 200.00)
]

# Udskriv patientinfo

patient.display_info()

# Udskriv alle procedure fra listen

total = 0
for proc in procedures:
    proc.display_info()
    total += proc.get_costProcedure()

# Udskriv totalpris

print(f"TOTAL CHARGES: ${total: .2f}")
