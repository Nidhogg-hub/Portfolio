import tkinter as tk
from tkinter import ttk, messagebox
from tkcalendar import DateEntry
import pandas as pd
import matplotlib.pyplot as plt
from datetime import datetime
import os


# --------------------------
# KONFIGURATION
# --------------------------

    #CSV-filnavn
FILNAVN = "traening.csv"

    # min vægt i kilogram
vaegt_kg = 100

    # MET-værdier (Metabolic Equivalent of Task) for aktiviter. Værdier dannet fra Compendium of Physical Activities (fitliferegime.com).
        # kun taget udgangs punkt i de aktiviteter jeg laver
met_vaerdier = {
    "svømning": 6.0,
    "kontorstol-cykel": 2.5,
    "gåtur": 3.0
    }


# --------------------------
# FUNKTIONER
# --------------------------

    # Beregning af kalorier brugt under aktivitet
def Beregn_kalorier(aktivitet, varighed_min, vaegt_kg):
    aktivitet = aktivitet.lower()
    met = met_vaerdier.get(aktivitet, None)
    if met is None:
        return None
    tid_timer = varighed_min / 60
    return round(met * vaegt_kg * tid_timer, 2) #formel for Kalorier = MET * kg * Timer

    #Funktion som viser graf og statistik 
def vis_statistik():
    """Viser statistik og graf efter GUI'en er lukket"""
    df = pd.read_csv(FILNAVN, encoding="latin1", parse_dates=["Dato"])

    # Beregn kalorier
    df["Kalorier"] = df.apply(
        lambda row: Beregn_kalorier(row["Aktivitet"], row["Varighed (min)"], vaegt_kg),
        axis=1
    )

    # Udskriv statistik
    print("\n📊 Træningsstatistik:")
    print(f"- Total træningstid: {df['Varighed (min)'].sum()} minutter")
    print(f"- Total kalorier forbrændt: {df['Kalorier'].sum()} kcal")

    print("\n📈 Gennemsnitligt kalorieforbrug pr. aktivitet:")
    print(df.groupby("Aktivitet")["Kalorier"].mean())

    kalorier_pr_dato = df.groupby("Dato")["Kalorier"].sum()
    print("\n🔥 Kalorieforbrug pr. dato:")
    print(kalorier_pr_dato)

    # Plot graf
    plt.figure(figsize=(10, 5))
    plt.bar(kalorier_pr_dato.index, kalorier_pr_dato.values, color="darkorange", edgecolor="black")
    plt.title("Kalorieforbrug pr. dato")
    plt.xlabel("Dato")
    plt.ylabel("Kalorier")
    plt.xticks(rotation=45)
    plt.grid(True)
    plt.tight_layout()
    plt.show()

    # Henter brugerens valg fra Dropdown og tekstfelt
def gem_aktivitet():
    aktivitet = aktivitet_cb.get()
    try:
        varighed = float(varighed_entry.get())
    except ValueError:
        messagebox.showerror("Fejl", "Varighed skal være et tal")
        return

    dato = kalender.get_date()

    ny_række = pd.DataFrame({
        "Dato": [dato],
        "Aktivitet": [aktivitet],
        "Varighed (min)": [varighed]
    })
    
    if os.path.exists(FILNAVN):
        ny_række.to_csv(FILNAVN, mode="a", header=False, index=False, encoding="latin1")
    else:
        ny_række.to_csv(FILNAVN, mode="w", header=True, index=False, encoding="latin1")

    messagebox.showinfo("Gemt", f"Aktiviteten '{aktivitet}' er gemt")
    root.destroy()  # Lukker GUI
    vis_statistik() # Viser statistik bagefter
    
# --------------------------
# GUI OPSÆTNING
# --------------------------
root = tk.Tk()
root.title("Træningsregistrering")

# Kalender
tk.Label(root, text="Vælg dato:").pack(pady=5)
kalender = DateEntry(root, width=12, background='darkblue',
                     foreground='white', borderwidth=2, date_pattern='dd-mm-yyyy')
kalender.pack(pady=5)

# Dropdown med aktiviteter
tk.Label(root, text="Vælg aktivitet:").pack(pady=5)
aktivitet_cb = ttk.Combobox(root, values=list(met_vaerdier.keys()), state="readonly")
aktivitet_cb.pack(pady=5)

# Varighed
tk.Label(root, text="Varighed (minutter):").pack(pady=5)
varighed_entry = tk.Entry(root)
varighed_entry.pack(pady=5)

# Gem-knap
gem_knap = tk.Button(root, text="Gem aktivitet", command=gem_aktivitet)
gem_knap.pack(pady=10)

root.mainloop()
